<?php

include_once 'Empleado.php';

$empleado1 = new Empleado('luis', 2500);
$empleado1->printMensagge();

$empleado2 = new Empleado('pepa', 3500);
$empleado2->printMensagge();

<?php
include_once 'Libro.php';

$libro1 = new Libro("Gabriel García Márquez", 1967, "Sudamericana", "Cien años de soledad", 471);

$libro1->mostarInfo();
